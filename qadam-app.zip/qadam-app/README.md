# Qadam: Step Counter & Walking Tracker (Flutter)

Ye DF ki walking steps app ka poora Flutter project hai. Code likha hua ready hai — isay GitHub par rakhna hai, GitHub Actions **free mein APK bana dega**.

## App mein kya hai
- Live step counting (phone ke sensor se), distance, calories, walking time
- Roz ka goal (default 10,000) progress ring ke saath
- **Har 100 qadam par girl voice motivation** (rotation mein 8 clips ready; 03, 04 aur milestone clips baad mein isi assets/audio folder mein daal kar dobara build karna hai)
- 1,000 / 5,000 / 10,000 qadam par khaas milestone awaz
- Pichhle 7 din ka chart + history
- Achievement badges aur streaks
- AdMob banner (abhi Google ke TEST ads chalenge — Play Store se pehle asli AdMob ID lagani hogi, neeche dekhein)

## GitHub par rakhna aur APK banana (step by step)
1. **GitHub account banayein** — github.com par free sign up (aapki email lagegi, verification code email par aayega).
2. **New repository** banayein — naam: `qadam-app`, Public rakhein (public repos par Actions ki minutes zyada milti hain), "Create repository".
3. **Files upload karein** — repository mein "uploading an existing file" par click karke is poore `qadam-app` folder ke andar wali tamam files/folders drag kar dein: `lib`, `assets`, `override`, `.github`, `pubspec.yaml`, `README.md`.
   - Khayal: `.github` folder chhupa hua (hidden) hota hai — computer par "show hidden files" on karke dekhein. Ye folder sab se zaroori hai, isi mein build wali file hai.
   - Asaan tareeqa: pehle zipped file `qadam-app.zip` apne computer par rakhein, unzip karein, phir andar ke folders drag karein.
4. **Build chalain** — repository ke **Actions** tab par jayein > **Build Qadam APK** > **Run workflow**. Takreeban 10-15 minute lagein ge.
5. **APK download karein** — build mukammal (green tick) ho jaye to usi page ke neeche **Artifacts** mein `qadam-apk` milega. Download karke unzip karein, andar `app-release.apk` hai.
6. **Phone par install karein** — APK phone mein bhejein, khol kar install karein ("unknown apps allow" ki ijazat deni hogi). Ye test build hai, is liye Play Store ke baghair seedha install ho jayega.

## Agar build fail ho jaye (red cross)
Ghabrayein nahi — fail wale step ki **screenshot ya laal text Muse ko bhej dein**, woh theek karke naya code de dega. Pehli dafa mein chhoti moti rukawat aam baat hai.

## Play Store se pehle ye 3 kaam baaki hain (baad mein, Muse ke saath)
1. **AdMob asli IDs** — AdMob account bana kar apni App ID aur Banner ID `override/AndroidManifest.xml` aur `lib/main.dart` mein TEST IDs ki jagah lagani hai (files mein comment se nishan laga diya hai ke kahan badalna hai).
2. **Signing key (keystore)** — Play Store AAB ke liye ek khaas key banani hoti hai; GitHub Secrets mein rakhi jayegi.
3. Baaki 5 voice clips assets/audio mein shamil karke dobara build.

## Ek imandari wali baat
Ye v1 hai: steps tab ginay jayenge jab app khuli ho ya background mein zinda ho. Kuch phones app ko maar dete hain to counting ruk sakti hai. **Har waqt background counting (foreground service) v2 ka kaam hai** — pehle v1 test karke dekhein steps aur awaz theek chalti hai ya nahi.
