import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

// ---------------------------------------------------------------------------
// In-app update check (DF ka order 2026-11-27): app apni website par rakhi
// aik choti si file (qadam-version.json) se apna version milati hai. Nayi
// version ho to user ko "Update karein" ka option milta hai jo seedha
// Amazon ke page par le jata hai, jahan se woh update download kar leta hai.
// Check fail ho jaye (internet na ho waghera) to khamoshi — user ko koi
// error nahi dikhta.
// ---------------------------------------------------------------------------

/// Is build ka version code — pubspec.yaml ke version (+N) ke saath barhao.
const int kAppVersionCode = 6;

/// Version wali file ka pata (Qadam ki apni site, GitHub Pages).
const String kVersionFeedUrl = 'https://qadamcounter.github.io/qadam-version.json';

Future<void> checkForUpdate(BuildContext context, {bool silent = true}) async {
  Map<String, dynamic>? data;
  try {
    final client = HttpClient()..connectionTimeout = const Duration(seconds: 8);
    final request = await client.getUrl(Uri.parse(kVersionFeedUrl));
    final response = await request.close();
    if (response.statusCode != 200) return;
    final body = await response.transform(utf8.decoder).join();
    data = jsonDecode(body) as Map<String, dynamic>;
    client.close();
  } catch (_) {
    return; // Internet/file ka masla — chup chaap aage barho.
  }

  final latest = (data['version_code'] as num?)?.toInt() ?? 0;
  final url = (data['url'] as String?) ?? '';
  if (!context.mounted) return;

  if (latest > kAppVersionCode && url.isNotEmpty) {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nayi update aagai hai'),
        content: const Text(
            'Qadam ka naya version tayyar hai. Update karne ke liye button dabayein — store ka page khul jayega, wahan se update download kar lein.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Baad mein'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.of(ctx).pop();
              final uri = Uri.parse(url);
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              }
            },
            child: const Text('Update karein'),
          ),
        ],
      ),
    );
  } else if (!silent) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Aap ki app bilkul up-to-date hai')),
    );
  }
}
