import 'dart:async';
import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:intl/intl.dart';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:unity_ads_plugin/unity_ads_plugin.dart';

import 'ads/unity_ads_config.dart';
import 'ads/unity_ads_service.dart';
import 'update_check.dart';

// Qadam: Step Counter & Walking Tracker
// Features: live step counting (device sensor), distance, calories, walking
// time, daily goal ring, English male voice har 100 qadam par step count
// announce karta hai ("100 steps", "200 steps", ... 20000 tak), 7-day
// history chart, achievement badges, Home par Surah Mulk
// player (chalte hue sunne ke liye), Unity banner seedha (AdMob approve
// nahi hai; approve ho to banner AdMob-first hoga), Unity interstitial
// History par kabhi kabhi.

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  await UnityAdsService.init();
  runApp(const QadamApp());
}

class QadamApp extends StatelessWidget {
  const QadamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Qadam',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0E9F6E)),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

// ---------------------------------------------------------------------------
// Central store: steps, settings, history, voice logic
// ---------------------------------------------------------------------------

/// Ek surah ka naam + uski audio file (assets/audio/ ke andar).
class SurahInfo {
  final String name;
  final String asset;
  const SurahInfo(this.name, this.asset);
}

class StepStore extends ChangeNotifier {
  /// Home card mein dikhne wali surahs ki list (dono surahs: Mulk aur Waqia).
  static const List<SurahInfo> surahs = [
    SurahInfo('Surah Mulk', 'audio/surah-mulk.mp3'),
    SurahInfo('Surah Waqia', 'audio/surah-waqia.mp3'),
  ];
  int todaySteps = 0;
  int walkSeconds = 0;
  int goal = 10000;
  double weightKg = 60;
  bool voiceOn = true;
  int _lastAnnouncedHundred = 0; // aakhri announce hua hundred (1 = 100 steps)
  String status = 'Sensor start ho raha hai...';
  Map<String, int> history = {}; // 'yyyy-MM-dd' -> steps

  SharedPreferences? _prefs;
  StreamSubscription<StepCount>? _sub;
  Timer? _timer;
  int? _lastCum;
  int _stepsAtLastTick = 0;
  final AudioPlayer _player = AudioPlayer();

  // Surah player ke liye alag player — voice clips wala player isko
  // stop nahi kar sakta, aur iski position/progress alag track hoti hai.
  // Ek hi player tamam surahs ke liye hai; surahIndex batata hai konsi
  // surah select/load hai, surahStarted batata hai ke wo kabhi start
  // hui hai (us ki row par slider/stop dikhta hai).
  final AudioPlayer _surahPlayer = AudioPlayer();
  int surahIndex = 0;
  bool surahStarted = false;
  bool surahPlaying = false;
  Duration surahPosition = Duration.zero;
  Duration surahDuration = Duration.zero;
  StreamSubscription<Duration>? _surahPosSub;
  StreamSubscription<Duration>? _surahDurSub;
  StreamSubscription<void>? _surahDoneSub;

  static const _strideMeters = 0.762; // average step length
  static final _fmt = DateFormat('yyyy-MM-dd');

  String get _todayKey => _fmt.format(DateTime.now());
  double get distanceKm => todaySteps * _strideMeters / 1000;
  double get calories => distanceKm * weightKg * 1.02;
  double get progress => goal == 0 ? 0 : (todaySteps / goal).clamp(0, 1);

  String get walkTimeText {
    final h = walkSeconds ~/ 3600;
    final m = (walkSeconds % 3600) ~/ 60;
    return h > 0 ? '${h}h ${m}m' : '${m} min';
  }

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    goal = _prefs!.getInt('goal') ?? 10000;
    weightKg = _prefs!.getDouble('weight') ?? 60;
    voiceOn = _prefs!.getBool('voice_on') ?? true;
    history = Map<String, int>.from(
        jsonDecode(_prefs!.getString('history') ?? '{}')
            .map((k, v) => MapEntry(k as String, (v as num).toInt())));

    final savedDate = _prefs!.getString('current_date');
    todaySteps = _prefs!.getInt('today_steps') ?? 0;
    walkSeconds = _prefs!.getInt('walk_seconds') ?? 0;
    _lastCum = _prefs!.getInt('last_cum');
    if (savedDate != null && savedDate != _todayKey) {
      // Day changed while app was closed: bank the old day, start fresh.
      if (todaySteps > 0) history[savedDate] = todaySteps;
      todaySteps = 0;
      walkSeconds = 0;
      _saveAll();
    }
    _stepsAtLastTick = todaySteps;
    // Restart par purane hundreds dobara announce na hon: counter aaj ke
    // maujooda steps se aage badhega. todaySteps khud persisted hai, is
    // liye alag se save karne ki zaroorat nahi — din badalne par ye
    // khud 0 ho jata hai kyunki todaySteps reset ho jata hai.
    _lastAnnouncedHundred = todaySteps ~/ 100;

    final perm = await Permission.activityRecognition.request();
    if (!perm.isGranted) {
      status = 'Permission chahiye: Settings se Physical Activity allow karein';
      notifyListeners();
    }

    _sub = Pedometer.stepCountStream.listen(_onStepCount,
        onError: (e) => _onSensorError(e.toString()));
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _tick());

    _surahDurSub = _surahPlayer.onDurationChanged.listen((d) {
      surahDuration = d;
      notifyListeners();
    });
    _surahPosSub = _surahPlayer.onPositionChanged.listen((p) {
      // UI sirf tab refresh karein jab second badle (fazool rebuilds na hon).
      final secondChanged = p.inSeconds != surahPosition.inSeconds;
      surahPosition = p;
      if (secondChanged) notifyListeners();
    });
    _surahDoneSub = _surahPlayer.onPlayerComplete.listen((_) {
      surahPlaying = false;
      surahStarted = false;
      surahPosition = Duration.zero;
      notifyListeners();
      // Surah khatam hona aik natural break hai — yahan video ad dikhao
      // (60s gap service ke andar mehfooz hai).
      UnityAdsService.showInterstitial();
    });
    notifyListeners();
  }

  void _onSensorError(String e) {
    status = 'Is phone mein step sensor nahi mila ($e)';
    notifyListeners();
  }

  void _tick() {
    // Walking time: if steps increased in the last 10 seconds, count them.
    if (todaySteps > _stepsAtLastTick) {
      walkSeconds += 10;
      _stepsAtLastTick = todaySteps;
    }
    // Midnight rollover while the app is open.
    if (_prefs!.getString('current_date') != _todayKey) {
      final old = _prefs!.getString('current_date');
      if (old != null && todaySteps > 0) history[old] = todaySteps;
      todaySteps = 0;
      walkSeconds = 0;
      _stepsAtLastTick = 0;
      _lastAnnouncedHundred = 0; // naya din: count announcements phir se 100 se
    }
    _saveAll();
    notifyListeners();
  }

  void _onStepCount(StepCount event) {
    final cum = event.steps; // steps since phone boot
    status = 'Counting... phone jaib/bag mein rakhein';
    if (_lastCum == null) {
      _lastCum = cum;
      _saveAll();
      notifyListeners();
      return;
    }
    int delta;
    if (cum >= _lastCum!) {
      delta = cum - _lastCum!;
    } else {
      // Phone rebooted: sensor counter restarted. Count what we can see.
      delta = cum;
    }
    if (delta <= 0) {
      _lastCum = cum;
      return;
    }
    todaySteps += delta;
    _lastCum = cum;
    _checkVoice(todaySteps);
    _saveAll();
    notifyListeners();
  }

  // Har naye hundred par count announce: 100 par "100 steps", 200 par
  // "200 steps", ... 20000 tak (clips: assets/audio/count-<n>.mp3).
  void _checkVoice(int next) {
    if (!voiceOn) return;
    // Surah chal rahi ho to announcement skip — tilawat darmiyan mein na
    // kate. Surah rukte hi agli boundary par taaza count announce hoga;
    // beech wale hundreds replay nahi hote.
    if (surahPlaying) return;
    final h = next ~/ 100;
    if (h <= _lastAnnouncedHundred || h < 1 || h > 200) return;
    _lastAnnouncedHundred = h;
    _player.stop();
    _player.play(AssetSource('audio/count-${h * 100}.mp3')).catchError((_) {});
  }

  void _saveAll() {
    _prefs?.setString('current_date', _todayKey);
    _prefs?.setInt('today_steps', todaySteps);
    _prefs?.setInt('walk_seconds', walkSeconds);
    if (_lastCum != null) _prefs?.setInt('last_cum', _lastCum!);
    _prefs?.setString('history', jsonEncode(history));
  }

  Future<void> setGoal(int g) async {
    goal = g;
    await _prefs?.setInt('goal', g);
    notifyListeners();
  }

  Future<void> setWeight(double w) async {
    weightKg = w;
    await _prefs?.setDouble('weight', w);
    notifyListeners();
  }

  Future<void> setVoice(bool v) async {
    voiceOn = v;
    await _prefs?.setBool('voice_on', v);
    notifyListeners();
  }

  // --- Surah player (Home card ki list se control hota hai) ----------------
  // index wali surah ka Play/Pause. Doosri surah dabayein to maujooda
  // surah ruk jati hai, position reset hoti hai aur nayi surah shuru se
  // chalti hai.
  Future<void> toggleSurah(int index) async {
    if (index != surahIndex || !surahStarted) {
      await _surahPlayer.stop();
      surahIndex = index;
      surahPosition = Duration.zero;
      surahDuration = Duration.zero;
      _player.stop(); // koi voice clip chal raha ho to pehle band karein
      await _surahPlayer.play(AssetSource(surahs[index].asset));
      surahPlaying = true;
      surahStarted = true;
    } else if (surahPlaying) {
      await _surahPlayer.pause();
      surahPlaying = false;
    } else {
      _player.stop(); // koi voice clip chal raha ho to pehle band karein
      if (surahPosition == Duration.zero) {
        await _surahPlayer.play(AssetSource(surahs[index].asset));
      } else {
        await _surahPlayer.resume();
      }
      surahPlaying = true;
    }
    notifyListeners();
  }

  Future<void> stopSurah() async {
    await _surahPlayer.stop();
    surahPlaying = false;
    surahStarted = false;
    surahPosition = Duration.zero;
    notifyListeners();
  }

  Future<void> seekSurah(double seconds) async {
    await _surahPlayer.seek(Duration(seconds: seconds.round()));
  }

  int get bestDay {
    var best = todaySteps;
    for (final v in history.values) {
      if (v > best) best = v;
    }
    return best;
  }

  int get streak {
    var count = 0;
    var day = DateTime.now();
    if (todaySteps == 0) day = day.subtract(const Duration(days: 1));
    while (true) {
      final key = _fmt.format(day);
      final s = key == _todayKey ? todaySteps : (history[key] ?? 0);
      if (s > 0) {
        count++;
        day = day.subtract(const Duration(days: 1));
      } else {
        break;
      }
    }
    return count;
  }

  @override
  void dispose() {
    _sub?.cancel();
    _timer?.cancel();
    _surahPosSub?.cancel();
    _surahDurSub?.cancel();
    _surahDoneSub?.cancel();
    _player.dispose();
    _surahPlayer.dispose();
    super.dispose();
  }
}

// ---------------------------------------------------------------------------
// Shell with bottom navigation + AdMob banner
// ---------------------------------------------------------------------------
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final StepStore store = StepStore();
  int _index = 0;
  int _navCount = 0;

  @override
  void initState() {
    super.initState();
    store.init();
    // App khulte hi khamoshi se update check — nayi version ho to
    // "Update karein" wala dialog khud aa jata hai.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) checkForUpdate(context);
    });
    // Banner seedha Unity se aata hai (DF ka faisla 2026-11-27): AdMob abhi
    // approve nahi, us ki fail-chain ki wajah se Unity banner kabhi load hi
    // nahi ho raha tha. AdMob approve ho jaye to banner wapas AdMob-first
    // karna hai — MobileAds init main() mein ab bhi chalta hai.
  }

  @override
  void dispose() {
    store.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(store: store),
      HistoryPage(store: store),
      BadgesPage(store: store),
      SettingsPage(store: store),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Qadam — Step Counter'),
        backgroundColor: const Color(0xFF0E9F6E),
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Expanded(child: pages[_index]),
          // Banner hamesha Unity ka — app khulte hi load shuru.
          const UnityBannerAd(
            placementId: UnityAdsConfig.bannerPlacementId,
          ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) {
          setState(() => _index = i);
          // DF ka order (2026-11-27): video ads zyada se zyada. Har doosri
          // tab tabdeeli par interstitial try karo — 60 second ka gap aur
          // ready-check service ke andar hai.
          _navCount++;
          if (_navCount % 2 == 0) UnityAdsService.showInterstitial();
        },
        destinations: const [
          NavigationDestination(icon: Icon(Icons.directions_walk), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'History'),
          NavigationDestination(icon: Icon(Icons.emoji_events), label: 'Badges'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------
String _fmtTime(Duration d) {
  final m = d.inMinutes.remainder(60).toString().padLeft(2, '0');
  final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
  return d.inHours > 0 ? '${d.inHours}:$m:$s' : '$m:$s';
}

class HomePage extends StatelessWidget {
  final StepStore store;
  const HomePage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 8),
              SizedBox(
                width: 230,
                height: 230,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 230,
                      height: 230,
                      child: CircularProgressIndicator(
                        value: store.progress,
                        strokeWidth: 16,
                        backgroundColor: Colors.green.shade100,
                        color: const Color(0xFF0E9F6E),
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${store.todaySteps}',
                          style: const TextStyle(
                              fontSize: 52, fontWeight: FontWeight.bold),
                        ),
                        const Text('steps aaj',
                            style: TextStyle(fontSize: 16, color: Colors.grey)),
                        Text('Goal: ${store.goal}',
                            style: const TextStyle(fontSize: 14)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _StatCard(
                      icon: Icons.route,
                      label: 'Distance',
                      value: '${store.distanceKm.toStringAsFixed(2)} km'),
                  _StatCard(
                      icon: Icons.local_fire_department,
                      label: 'Calories',
                      value: '${store.calories.toStringAsFixed(0)} kcal'),
                  _StatCard(
                      icon: Icons.timer,
                      label: 'Time',
                      value: store.walkTimeText),
                ],
              ),
              const SizedBox(height: 20),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.record_voice_over,
                      color: Color(0xFF0E9F6E)),
                  title: const Text('Step Count Voice'),
                  subtitle: const Text('Har 100 qadam par count ki awaz'),
                  trailing: Switch(
                    value: store.voiceOn,
                    onChanged: (v) => store.setVoice(v),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              Card(
                child: Column(
                  children: [
                    const ListTile(
                      leading: Icon(Icons.menu_book,
                          color: Color(0xFF0E9F6E)),
                      title: Text('Surahs'),
                      subtitle: Text('Listen while you walk'),
                    ),
                    const Divider(height: 1),
                    for (var i = 0; i < StepStore.surahs.length; i++) ...[
                      if (i > 0) const Divider(height: 1),
                      _surahTile(i),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 8),
              Text(store.status,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.grey)),
            ],
          ),
        );
      },
    );
  }

  // Ek surah ki row: naam + apna Play/Pause button. Jo surah load hai
  // sirf usi ki row par seek slider + time + Stop dikhta hai, taake
  // list compact rahe.
  Widget _surahTile(int i) {
    final active = store.surahStarted && store.surahIndex == i;
    return Column(
      children: [
        ListTile(
          title: Text(StepStore.surahs[i].name),
          trailing: IconButton(
            icon: Icon(
              active && store.surahPlaying
                  ? Icons.pause_circle_filled
                  : Icons.play_circle_fill,
              size: 38,
              color: const Color(0xFF0E9F6E),
            ),
            onPressed: () => store.toggleSurah(i),
          ),
        ),
        if (active)
          Padding(
            padding: const EdgeInsets.only(left: 8, right: 16),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.stop_circle_outlined),
                  color: Colors.grey.shade700,
                  onPressed: () => store.stopSurah(),
                ),
                Text(_fmtTime(store.surahPosition),
                    style: const TextStyle(fontSize: 12)),
                Expanded(
                  child: Slider(
                    value: store.surahDuration.inSeconds == 0
                        ? 0
                        : store.surahPosition.inSeconds
                            .clamp(0, store.surahDuration.inSeconds)
                            .toDouble(),
                    max: store.surahDuration.inSeconds == 0
                        ? 1
                        : store.surahDuration.inSeconds.toDouble(),
                    activeColor: const Color(0xFF0E9F6E),
                    onChanged: store.surahDuration.inSeconds == 0
                        ? null
                        : (v) => store.seekSurah(v),
                  ),
                ),
                Text(_fmtTime(store.surahDuration),
                    style: const TextStyle(fontSize: 12)),
              ],
            ),
          ),
      ],
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _StatCard(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFF0E9F6E)),
            const SizedBox(height: 6),
            Text(value,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text(label, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// History (7-day chart + list)
// ---------------------------------------------------------------------------
class HistoryPage extends StatelessWidget {
  final StepStore store;
  const HistoryPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final days = <DateTime>[];
        final values = <int>[];
        for (var i = 6; i >= 0; i--) {
          final d = DateTime.now().subtract(Duration(days: i));
          days.add(d);
          final key = DateFormat('yyyy-MM-dd').format(d);
          values.add(i == 0 ? store.todaySteps : (store.history[key] ?? 0));
        }
        final maxV = (values.reduce((a, b) => a > b ? a : b)).toDouble();
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Pichhle 7 din',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              SizedBox(
                height: 220,
                child: BarChart(
                  BarChartData(
                    maxY: maxV <= 0 ? 1000 : maxV * 1.2,
                    gridData:
                        const FlGridData(show: true, drawVerticalLine: false),
                    borderData: FlBorderData(show: false),
                    titlesData: FlTitlesData(
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 38,
                          getTitlesWidget: (v, _) => Text(
                              v.toInt().toString(),
                              style: const TextStyle(fontSize: 9)),
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 26,
                          getTitlesWidget: (v, _) {
                            final i = v.toInt();
                            if (i < 0 || i >= days.length) {
                              return const SizedBox();
                            }
                            return Text(
                                DateFormat('E').format(days[i]),
                                style: const TextStyle(fontSize: 10));
                          },
                        ),
                      ),
                    ),
                    barGroups: [
                      for (var i = 0; i < values.length; i++)
                        BarChartGroupData(x: i, barRods: [
                          BarChartRodData(
                            toY: values[i].toDouble(),
                            width: 18,
                            color: i == values.length - 1
                                ? const Color(0xFFF59E0B)
                                : const Color(0xFF0E9F6E),
                            borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(4)),
                          ),
                        ]),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: ListView.builder(
                  itemCount: days.length,
                  itemBuilder: (context, idx) {
                    final i = days.length - 1 - idx;
                    return ListTile(
                      leading: const Icon(Icons.calendar_today, size: 18),
                      title: Text(DateFormat('EEEE, d MMM').format(days[i])),
                      trailing: Text('${values[i]} steps',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Badges
// ---------------------------------------------------------------------------
class BadgesPage extends StatelessWidget {
  final StepStore store;
  const BadgesPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final badges = <(String, String, bool)>[
          ('Shuruaat', 'Pehle 1,000 qadam', store.bestDay >= 1000),
          ('Half Goal', 'Ek din mein 5,000 qadam', store.bestDay >= 5000),
          ('Champion', 'Ek din mein 10,000 qadam', store.bestDay >= 10000),
          ('Super Walker', 'Ek din mein 15,000 qadam', store.bestDay >= 15000),
          ('Pro Walker', 'Ek din mein 20,000 qadam', store.bestDay >= 20000),
          ('Streak x3', 'Lagataar 3 din chalein', store.streak >= 3),
          ('Streak x7', 'Lagataar 7 din chalein', store.streak >= 7),
        ];
        return GridView.count(
          crossAxisCount: 2,
          padding: const EdgeInsets.all(16),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          children: [
            for (final b in badges)
              Card(
                color: b.$3 ? Colors.amber.shade50 : null,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.emoji_events,
                        size: 44,
                        color: b.$3 ? Colors.amber.shade700 : Colors.grey),
                    const SizedBox(height: 8),
                    Text(b.$1,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(b.$2,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12)),
                    ),
                    Text(b.$3 ? 'Mil gaya!' : 'Abhi baaki hai',
                        style: TextStyle(
                            color: b.$3 ? Colors.green : Colors.grey,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
          ],
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
class SettingsPage extends StatefulWidget {
  final StepStore store;
  const SettingsPage({super.key, required this.store});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController _goalCtrl;
  late final TextEditingController _weightCtrl;

  @override
  void initState() {
    super.initState();
    _goalCtrl = TextEditingController(text: '${widget.store.goal}');
    _weightCtrl =
        TextEditingController(text: '${widget.store.weightKg.toStringAsFixed(0)}');
  }

  @override
  void dispose() {
    _goalCtrl.dispose();
    _weightCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: _goalCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Roz ka goal (steps)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _weightCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Aapka wazan (kg) — calories ke hisaab ke liye',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.save),
              label: const Text('Save karein'),
              onPressed: () async {
                final g = int.tryParse(_goalCtrl.text);
                final w = double.tryParse(_weightCtrl.text);
                if (g != null && g >= 1000) await store.setGoal(g);
                if (w != null && w >= 20 && w <= 300) {
                  await store.setWeight(w);
                }
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Settings save ho gayi')));
                }
              },
            ),
            const Divider(height: 32),
            SwitchListTile(
              title: const Text('Step Count Voice'),
              subtitle: const Text('Har 100 qadam par count ki awaz'),
              value: store.voiceOn,
              onChanged: (v) => store.setVoice(v),
            ),
            ListTile(
              leading: const Icon(Icons.system_update),
              title: const Text('App Update'),
              subtitle: const Text('Nayi version hai ya nahi, check karein'),
              trailing: const Icon(Icons.chevron_right),
              onTap: () => checkForUpdate(context, silent: false),
            ),
            const ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('Note'),
              subtitle: Text(
                  'Steps phone ke sensor se ginte hain. Behtareen result ke liye phone jaib ya bag mein rakhein. Kuch phones mein app band karne se counting ruk sakti hai — ye v1 hai, background counting v2 mein aayegi.'),
            ),
          ],
        );
      },
    );
  }
}
