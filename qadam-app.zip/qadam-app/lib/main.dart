import 'dart:async';
import 'dart:convert';

import 'package:audioplayers/audioplayers.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:intl/intl.dart';
import 'package:pedometer/pedometer.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Qadam: Step Counter & Walking Tracker
// Features: live step counting (device sensor), distance, calories, walking
// time, daily goal ring, girl-voice motivation every 100 steps + milestone
// clips, 7-day history chart, achievement badges, AdMob banner (TEST ids).

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  runApp(const QadamApp());
}

class QadamApp extends StatelessWidget {
  const QadamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Qadam',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0E9F6E)),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

// ---------------------------------------------------------------------------
// Central store: steps, settings, history, voice logic
// ---------------------------------------------------------------------------
class StepStore extends ChangeNotifier {
  int todaySteps = 0;
  int walkSeconds = 0;
  int goal = 10000;
  double weightKg = 60;
  bool voiceOn = true;
  int clipIndex = 0;
  String status = 'Sensor start ho raha hai...';
  Map<String, int> history = {}; // 'yyyy-MM-dd' -> steps

  SharedPreferences? _prefs;
  StreamSubscription<StepCount>? _sub;
  Timer? _timer;
  int? _lastCum;
  int _stepsAtLastTick = 0;
  final AudioPlayer _player = AudioPlayer();

  static const _strideMeters = 0.762; // average step length
  static final _fmt = DateFormat('yyyy-MM-dd');

  String get _todayKey => _fmt.format(DateTime.now());
  double get distanceKm => todaySteps * _strideMeters / 1000;
  double get calories => distanceKm * weightKg * 1.02;
  double get progress => goal == 0 ? 0 : (todaySteps / goal).clamp(0, 1);

  String get walkTimeText {
    final h = walkSeconds ~/ 3600;
    final m = (walkSeconds % 3600) ~/ 60;
    return h > 0 ? '${h}h ${m}m' : '${m} min';
  }

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    goal = _prefs!.getInt('goal') ?? 10000;
    weightKg = _prefs!.getDouble('weight') ?? 60;
    voiceOn = _prefs!.getBool('voice_on') ?? true;
    clipIndex = _prefs!.getInt('clip_index') ?? 0;
    history = Map<String, int>.from(
        jsonDecode(_prefs!.getString('history') ?? '{}')
            .map((k, v) => MapEntry(k as String, (v as num).toInt())));

    final savedDate = _prefs!.getString('current_date');
    todaySteps = _prefs!.getInt('today_steps') ?? 0;
    walkSeconds = _prefs!.getInt('walk_seconds') ?? 0;
    _lastCum = _prefs!.getInt('last_cum');
    if (savedDate != null && savedDate != _todayKey) {
      // Day changed while app was closed: bank the old day, start fresh.
      if (todaySteps > 0) history[savedDate] = todaySteps;
      todaySteps = 0;
      walkSeconds = 0;
      _saveAll();
    }
    _stepsAtLastTick = todaySteps;

    final perm = await Permission.activityRecognition.request();
    if (!perm.isGranted) {
      status = 'Permission chahiye: Settings se Physical Activity allow karein';
      notifyListeners();
    }

    _sub = Pedometer.stepCountStream.listen(_onStepCount,
        onError: (e) => _onSensorError(e.toString()));
    _timer = Timer.periodic(const Duration(seconds: 10), (_) => _tick());
    notifyListeners();
  }

  void _onSensorError(String e) {
    status = 'Is phone mein step sensor nahi mila ($e)';
    notifyListeners();
  }

  void _tick() {
    // Walking time: if steps increased in the last 10 seconds, count them.
    if (todaySteps > _stepsAtLastTick) {
      walkSeconds += 10;
      _stepsAtLastTick = todaySteps;
    }
    // Midnight rollover while the app is open.
    if (_prefs!.getString('current_date') != _todayKey) {
      final old = _prefs!.getString('current_date');
      if (old != null && todaySteps > 0) history[old] = todaySteps;
      todaySteps = 0;
      walkSeconds = 0;
      _stepsAtLastTick = 0;
    }
    _saveAll();
    notifyListeners();
  }

  void _onStepCount(StepCount event) {
    final cum = event.steps; // steps since phone boot
    status = 'Counting... phone jaib/bag mein rakhein';
    if (_lastCum == null) {
      _lastCum = cum;
      _saveAll();
      notifyListeners();
      return;
    }
    int delta;
    if (cum >= _lastCum!) {
      delta = cum - _lastCum!;
    } else {
      // Phone rebooted: sensor counter restarted. Count what we can see.
      delta = cum;
    }
    if (delta <= 0) {
      _lastCum = cum;
      return;
    }
    final prev = todaySteps;
    todaySteps += delta;
    _lastCum = cum;
    _checkVoice(prev, todaySteps);
    _saveAll();
    notifyListeners();
  }

  void _checkVoice(int prev, int next) {
    if (!voiceOn) return;
    if (next ~/ 100 <= prev ~/ 100) return; // no 100-boundary crossed
    String file;
    if (prev < 10000 && next >= 10000) {
      file = 'audio/milestone-10000.mp3';
    } else if (prev < 5000 && next >= 5000) {
      file = 'audio/milestone-5000.mp3';
    } else if (prev < 1000 && next >= 1000) {
      file = 'audio/milestone-1000.mp3';
    } else {
      // Rotation over the clips that exist in assets/audio today.
      // Add 03 and 04 to this list when those clips are ready.
      const rotation = [1, 2, 5, 6, 7, 8, 9, 10];
      clipIndex = (clipIndex + 1) % rotation.length;
      final n = rotation[clipIndex];
      file = 'audio/motivation-${n.toString().padLeft(2, '0')}.mp3';
      _prefs?.setInt('clip_index', clipIndex);
    }
    _player.stop();
    _player.play(AssetSource(file)).catchError((_) {});
  }

  void _saveAll() {
    _prefs?.setString('current_date', _todayKey);
    _prefs?.setInt('today_steps', todaySteps);
    _prefs?.setInt('walk_seconds', walkSeconds);
    if (_lastCum != null) _prefs?.setInt('last_cum', _lastCum!);
    _prefs?.setString('history', jsonEncode(history));
  }

  Future<void> setGoal(int g) async {
    goal = g;
    await _prefs?.setInt('goal', g);
    notifyListeners();
  }

  Future<void> setWeight(double w) async {
    weightKg = w;
    await _prefs?.setDouble('weight', w);
    notifyListeners();
  }

  Future<void> setVoice(bool v) async {
    voiceOn = v;
    await _prefs?.setBool('voice_on', v);
    notifyListeners();
  }

  int get bestDay {
    var best = todaySteps;
    for (final v in history.values) {
      if (v > best) best = v;
    }
    return best;
  }

  int get streak {
    var count = 0;
    var day = DateTime.now();
    if (todaySteps == 0) day = day.subtract(const Duration(days: 1));
    while (true) {
      final key = _fmt.format(day);
      final s = key == _todayKey ? todaySteps : (history[key] ?? 0);
      if (s > 0) {
        count++;
        day = day.subtract(const Duration(days: 1));
      } else {
        break;
      }
    }
    return count;
  }

  @override
  void dispose() {
    _sub?.cancel();
    _timer?.cancel();
    _player.dispose();
    super.dispose();
  }
}

// ---------------------------------------------------------------------------
// Shell with bottom navigation + AdMob banner
// ---------------------------------------------------------------------------
class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final StepStore store = StepStore();
  int _index = 0;
  BannerAd? _banner;
  bool _bannerLoaded = false;

  @override
  void initState() {
    super.initState();
    store.init();
    // TEST banner id. Replace with your real AdMob banner id before release.
    _banner = BannerAd(
      size: AdSize.banner,
      adUnitId: 'ca-app-pub-3940256099942544/6300978111',
      listener: BannerAdListener(
        onAdLoaded: (_) => setState(() => _bannerLoaded = true),
        onAdFailedToLoad: (ad, _) => ad.dispose(),
      ),
      request: const AdRequest(),
    )..load();
  }

  @override
  void dispose() {
    store.dispose();
    _banner?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(store: store),
      HistoryPage(store: store),
      BadgesPage(store: store),
      SettingsPage(store: store),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('Qadam — Step Counter'),
        backgroundColor: const Color(0xFF0E9F6E),
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          Expanded(child: pages[_index]),
          if (_bannerLoaded && _banner != null)
            SizedBox(
              width: _banner!.size.width.toDouble(),
              height: _banner!.size.height.toDouble(),
              child: AdWidget(ad: _banner!),
            ),
        ],
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.directions_walk), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'History'),
          NavigationDestination(icon: Icon(Icons.emoji_events), label: 'Badges'),
          NavigationDestination(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------
class HomePage extends StatelessWidget {
  final StepStore store;
  const HomePage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              const SizedBox(height: 8),
              SizedBox(
                width: 230,
                height: 230,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      width: 230,
                      height: 230,
                      child: CircularProgressIndicator(
                        value: store.progress,
                        strokeWidth: 16,
                        backgroundColor: Colors.green.shade100,
                        color: const Color(0xFF0E9F6E),
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          '${store.todaySteps}',
                          style: const TextStyle(
                              fontSize: 52, fontWeight: FontWeight.bold),
                        ),
                        const Text('steps aaj',
                            style: TextStyle(fontSize: 16, color: Colors.grey)),
                        Text('Goal: ${store.goal}',
                            style: const TextStyle(fontSize: 14)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _StatCard(
                      icon: Icons.route,
                      label: 'Distance',
                      value: '${store.distanceKm.toStringAsFixed(2)} km'),
                  _StatCard(
                      icon: Icons.local_fire_department,
                      label: 'Calories',
                      value: '${store.calories.toStringAsFixed(0)} kcal'),
                  _StatCard(
                      icon: Icons.timer,
                      label: 'Time',
                      value: store.walkTimeText),
                ],
              ),
              const SizedBox(height: 20),
              Card(
                child: ListTile(
                  leading: const Icon(Icons.record_voice_over,
                      color: Color(0xFF0E9F6E)),
                  title: const Text('Voice Motivation'),
                  subtitle: const Text('Har 100 qadam par hosla wali awaz'),
                  trailing: Switch(
                    value: store.voiceOn,
                    onChanged: (v) => store.setVoice(v),
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(store.status,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.grey)),
            ],
          ),
        );
      },
    );
  }
}

class _StatCard extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  const _StatCard(
      {required this.icon, required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        child: Column(
          children: [
            Icon(icon, color: const Color(0xFF0E9F6E)),
            const SizedBox(height: 6),
            Text(value,
                style:
                    const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text(label, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// History (7-day chart + list)
// ---------------------------------------------------------------------------
class HistoryPage extends StatelessWidget {
  final StepStore store;
  const HistoryPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final days = <DateTime>[];
        final values = <int>[];
        for (var i = 6; i >= 0; i--) {
          final d = DateTime.now().subtract(Duration(days: i));
          days.add(d);
          final key = DateFormat('yyyy-MM-dd').format(d);
          values.add(i == 0 ? store.todaySteps : (store.history[key] ?? 0));
        }
        final maxV = (values.reduce((a, b) => a > b ? a : b)).toDouble();
        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Pichhle 7 din',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              SizedBox(
                height: 220,
                child: BarChart(
                  BarChartData(
                    maxY: maxV <= 0 ? 1000 : maxV * 1.2,
                    gridData:
                        const FlGridData(show: true, drawVerticalLine: false),
                    borderData: FlBorderData(show: false),
                    titlesData: FlTitlesData(
                      topTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      rightTitles: const AxisTitles(
                          sideTitles: SideTitles(showTitles: false)),
                      leftTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 38,
                          getTitlesWidget: (v, _) => Text(
                              v.toInt().toString(),
                              style: const TextStyle(fontSize: 9)),
                        ),
                      ),
                      bottomTitles: AxisTitles(
                        sideTitles: SideTitles(
                          showTitles: true,
                          reservedSize: 26,
                          getTitlesWidget: (v, _) {
                            final i = v.toInt();
                            if (i < 0 || i >= days.length) {
                              return const SizedBox();
                            }
                            return Text(
                                DateFormat('E').format(days[i]),
                                style: const TextStyle(fontSize: 10));
                          },
                        ),
                      ),
                    ),
                    barGroups: [
                      for (var i = 0; i < values.length; i++)
                        BarChartGroupData(x: i, barRods: [
                          BarChartRodData(
                            toY: values[i].toDouble(),
                            width: 18,
                            color: i == values.length - 1
                                ? const Color(0xFFF59E0B)
                                : const Color(0xFF0E9F6E),
                            borderRadius: const BorderRadius.vertical(
                                top: Radius.circular(4)),
                          ),
                        ]),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Expanded(
                child: ListView.builder(
                  itemCount: days.length,
                  itemBuilder: (context, idx) {
                    final i = days.length - 1 - idx;
                    return ListTile(
                      leading: const Icon(Icons.calendar_today, size: 18),
                      title: Text(DateFormat('EEEE, d MMM').format(days[i])),
                      trailing: Text('${values[i]} steps',
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                    );
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Badges
// ---------------------------------------------------------------------------
class BadgesPage extends StatelessWidget {
  final StepStore store;
  const BadgesPage({super.key, required this.store});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        final badges = <(String, String, bool)>[
          ('Shuruaat', 'Pehle 1,000 qadam', store.bestDay >= 1000),
          ('Half Goal', 'Ek din mein 5,000 qadam', store.bestDay >= 5000),
          ('Champion', 'Ek din mein 10,000 qadam', store.bestDay >= 10000),
          ('Super Walker', 'Ek din mein 15,000 qadam', store.bestDay >= 15000),
          ('Pro Walker', 'Ek din mein 20,000 qadam', store.bestDay >= 20000),
          ('Streak x3', 'Lagataar 3 din chalein', store.streak >= 3),
          ('Streak x7', 'Lagataar 7 din chalein', store.streak >= 7),
        ];
        return GridView.count(
          crossAxisCount: 2,
          padding: const EdgeInsets.all(16),
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          children: [
            for (final b in badges)
              Card(
                color: b.$3 ? Colors.amber.shade50 : null,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.emoji_events,
                        size: 44,
                        color: b.$3 ? Colors.amber.shade700 : Colors.grey),
                    const SizedBox(height: 8),
                    Text(b.$1,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 16)),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(b.$2,
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12)),
                    ),
                    Text(b.$3 ? 'Mil gaya!' : 'Abhi baaki hai',
                        style: TextStyle(
                            color: b.$3 ? Colors.green : Colors.grey,
                            fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
          ],
        );
      },
    );
  }
}

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------
class SettingsPage extends StatefulWidget {
  final StepStore store;
  const SettingsPage({super.key, required this.store});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final TextEditingController _goalCtrl;
  late final TextEditingController _weightCtrl;

  @override
  void initState() {
    super.initState();
    _goalCtrl = TextEditingController(text: '${widget.store.goal}');
    _weightCtrl =
        TextEditingController(text: '${widget.store.weightKg.toStringAsFixed(0)}');
  }

  @override
  void dispose() {
    _goalCtrl.dispose();
    _weightCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final store = widget.store;
    return AnimatedBuilder(
      animation: store,
      builder: (context, _) {
        return ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextField(
              controller: _goalCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Roz ka goal (steps)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _weightCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'Aapka wazan (kg) — calories ke hisaab ke liye',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            ElevatedButton.icon(
              icon: const Icon(Icons.save),
              label: const Text('Save karein'),
              onPressed: () async {
                final g = int.tryParse(_goalCtrl.text);
                final w = double.tryParse(_weightCtrl.text);
                if (g != null && g >= 1000) await store.setGoal(g);
                if (w != null && w >= 20 && w <= 300) {
                  await store.setWeight(w);
                }
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Settings save ho gayi')));
                }
              },
            ),
            const Divider(height: 32),
            SwitchListTile(
              title: const Text('Voice Motivation'),
              subtitle: const Text('Har 100 qadam par girl voice ka hosla'),
              value: store.voiceOn,
              onChanged: (v) => store.setVoice(v),
            ),
            const ListTile(
              leading: Icon(Icons.info_outline),
              title: Text('Note'),
              subtitle: Text(
                  'Steps phone ke sensor se ginte hain. Behtareen result ke liye phone jaib ya bag mein rakhein. Kuch phones mein app band karne se counting ruk sakti hai — ye v1 hai, background counting v2 mein aayegi.'),
            ),
          ],
        );
      },
    );
  }
}
