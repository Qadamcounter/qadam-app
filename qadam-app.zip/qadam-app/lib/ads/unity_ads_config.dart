// ---------------------------------------------------------------------------
// Unity Ads configuration — Qadam v1.0.3
// ---------------------------------------------------------------------------
// Unity dashboard (cloud.unity.com, org "Qadam Apps", project "Qadam",
// account casenovatv@gmail.com) se liya gaya ASLI Android Game ID aur
// placements — 2026-11-27 ko set kiye gaye. Dashboard ne custom placement
// naam nahi diye; us ke apne diye hue naam "BP_" prefix ke saath hain,
// is liye code mein bhi bilkul wahi naam hain.
class UnityAdsConfig {
  /// Android Game ID (Unity dashboard se).
  static const String androidGameId = '800455751';

  /// Banner placement — MainShell mein AdMob banner ke fallback ke tor par.
  static const String bannerPlacementId = 'BP_Banner_Android';

  /// Interstitial placement — History screen kholne par kabhi kabhi.
  static const String interstitialPlacementId = 'BP_Interstitial_Android';

  /// Hamesha false — Game ID asli hai, test mode off rahega.
  static bool get isPlaceholder => false;
}
