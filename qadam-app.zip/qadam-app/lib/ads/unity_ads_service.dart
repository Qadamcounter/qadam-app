import 'package:unity_ads_plugin/unity_ads_plugin.dart';

import 'unity_ads_config.dart';

// ---------------------------------------------------------------------------
// Unity Ads service: SDK init + interstitial load/show
// ---------------------------------------------------------------------------
// Banner widget (UnityBannerAd) MainShell khud lagata hai jab AdMob banner
// load na ho — is service ka kaam sirf init aur interstitial hai.
// Interstitial pehle se load karke rakhte hain taake zaroorat par foran
// dikh sake; dikhane ke baad agla khud load ho jata hai.
class UnityAdsService {
  static bool _initialized = false;
  static bool _interstitialReady = false;
  static bool _interstitialLoading = false;

  static Future<void> init() async {
    await UnityAds.init(
      gameId: UnityAdsConfig.androidGameId,
      // Placeholder Game ID par test mode: asli ID lagte hi live ads.
      testMode: UnityAdsConfig.isPlaceholder,
      onComplete: () {
        _initialized = true;
        loadInterstitial();
      },
      onFailed: (_, __) => _initialized = false,
    );
  }

  static void loadInterstitial() {
    if (!_initialized || _interstitialLoading || _interstitialReady) return;
    _interstitialLoading = true;
    UnityAds.load(
      placementId: UnityAdsConfig.interstitialPlacementId,
      onComplete: (_) {
        _interstitialLoading = false;
        _interstitialReady = true;
      },
      onFailed: (_, __, ___) {
        _interstitialLoading = false;
        _interstitialReady = false;
      },
    );
  }

  /// Ready ho to interstitial dikhao. True matlab ad dikhaya gaya.
  static bool showInterstitial() {
    if (!_interstitialReady) {
      loadInterstitial(); // is dafa nahi, agli dafa ke liye tayyar karo
      return false;
    }
    _interstitialReady = false;
    UnityAds.showVideoAd(
      placementId: UnityAdsConfig.interstitialPlacementId,
      onComplete: (_) => loadInterstitial(),
      onSkipped: (_) => loadInterstitial(),
      onFailed: (_, __, ___) => loadInterstitial(),
    );
    return true;
  }
}
